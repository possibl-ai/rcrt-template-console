# @possibl/rcrt-ui — Changelog

All notable changes are documented here. Follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) + [semver](https://semver.org/).

## 0.3.0 — 2026-06-18

Native chat file attachments (route-agnostic multimodal).

### Changed

- **`Chat` now sends uploaded files as native attachments.** `handleSend`
  uploads each file, then passes `attachments: [{ file_breadcrumb_id }]` to
  `sendChat` instead of injecting an `[Attached: … (file_id: …)]` text line and
  a `file:` tag (the text-only workaround the multimodal `/v1/chat` contract
  replaces). The model now receives the file directly. Text-only sends are
  unchanged.
- **`RcrtClientLike.sendChat`** gains an optional `attachments?:
  ChatAttachmentRef[]` parameter, matching `@possibl/rcrt-api`'s `sendChat`.

### Added

- **`ChatAttachmentRef`** type, exported from the chat module.

## 0.2.2 — 2026-06-17

Hide internal multi-agent orchestration noise from the chat stream. Ports the
fixes from rcrt-studio #4/#5 upstream so every consumer benefits — previously
agents appeared to "abandon" the conversation ("builder has left the
conversation" / "Done for now — send a message to continue").

### Fixed

- **`leave-session` is filtered unconditionally** from the chat stream, not just
  when it lands as the trailing item. It's internal orchestration agents use to
  hand off between turns and should never be visible to the user. Removed the
  fragile trailing-`lastItem`/`slice(0, -1)` peel-off, the `TurnCompleteDivider`
  ("Done for now — send a message to continue"), and the `leave-session` entry
  from `TOOL_LABELS`.
- **`interpret:session-participant` breadcrumbs no longer render.**
  `breadcrumbToStreamItem` returns `null` for them, and `Chat`'s live `onMessage`
  handler skips `participant` items — session join/leave plumbing is no longer
  appended to the stream.

## 0.2.1 — 2026-06-17

Fail-loud chat. Aligns the chat primitive with the no-fallback LLM contract
(see `docs/design/LLM_PROVIDER_MODEL_RESOLUTION.md`): failures are now visibly
surfaced rather than disguised or swallowed.

### Fixed

- **`sendChat` failures render a real `error-message` card** instead of a fake
  "System" agent bubble — same card used for user-facing `interpret:error`
  breadcrumbs (`error_type: send_failed`, user-actionable).
- **Fatal SSE disconnects surface a visible `error-message` card**
  (`error_type: connection_lost`) instead of being console-only; the input is
  re-enabled and any in-flight streaming state is cleared so the user can
  retry/reload. Flapping streams don't stack duplicate cards.
- Added friendly titles for the `send_failed` and `connection_lost` error
  types in the error card.

## 0.2.0 — 2026-06-13

First published release. Previously a private, `workspace`-only package vendored
by consumers (the studio and the MSP console copied `src/` into their trees);
this release makes `@possibl/rcrt-ui` a real, installable package on
`@possibl/rcrt-sdk` 0.2.0.

### Packaging

- Published to npm with subpath exports: `.` (everything), `./chat`, `./widgets`,
  `./sapl`, `./app-control`, `./layout`. In-repo consumers resolve raw `src/*`;
  `publishConfig` redirects to compiled `dist/` (clean JS + `.d.ts`) at pack time.
- Dropped the legacy `@possibl/rcrt-api` dependency. The package no longer takes a
  hard wire-client dependency: it consumes the `@possibl/rcrt-sdk` `Breadcrumb`
  type and accepts a host-provided client through structural seams
  (`RcrtClientLike`, the manifest client, `useDataSource`'s client), so the host
  owns the single client instance.
- `@possibl/rcrt-sdk` is a **peer dependency** (`>=0.1.3`) alongside `react` /
  `react-dom`. `lucide-react` is the only runtime dependency.
- Added `tsconfig.json` / `tsconfig.build.json`, `build` + `prepack` scripts,
  `LICENSE`, this changelog and a tag-driven publish workflow (`ui-v*`),
  mirroring `@possibl/rcrt-sdk` and `@possibl/rcrt-app-kit`.

### Type safety (clean strict build)

The package now type-checks and builds cleanly under the same strict config as
the SDK and app-kit (`strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`,
`noUnusedLocals`). Fixed the pre-existing error classes that previously only
surfaced in consumers' vendored copies:

- **`unknown` not assignable to `ReactNode`** — typed config shapes for the
  stream/feed cards (`FactCard`, `HITLCard`, `ReasoningChain`, `ChallengeCard`,
  `DocumentCard`) and boolean-coerced (`!!`) JSX guards across the SAPL
  primitives instead of leaking `unknown` into child position.
- **Implicit `any`** — `@possibl/rcrt-sdk` `Breadcrumb` typing in
  `breadcrumb-to-stream`, explicit types in `useDataSource`.
- **`noUncheckedIndexedAccess` / possibly-undefined** — guarded array and lookup
  access in the SAPL primitives, markdown renderers, manifest publisher,
  `ActivityFeed`, and the studio cards (literal fallbacks for style maps).
- **New-JSX-transform hygiene** — removed unused default `React` imports across
  ~45 widget/chat files; added `breadcrumb` to `WidgetProps`; removed a dangling
  `ChatStreamRenderProps` re-export.
