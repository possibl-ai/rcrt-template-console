# @possibl/rcrt-ui — Changelog

All notable changes are documented here. Follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) + [semver](https://semver.org/).

## 0.2.0 — 2026-06-13

First published release. Previously a private, `workspace`-only package vendored
by consumers (the studio and the MSP console copied `src/` into their trees);
this release makes `@possibl/rcrt-ui` a real, installable package on
`@possibl/rcrt-sdk` 0.2.0.

### Packaging

- Published to npm with subpath exports: `.` (everything), `./chat`, `./widgets`,
  `./sapl`, `./app-control`, `./layout`. In-repo consumers resolve raw `src/*`;
  `publishConfig` redirects to compiled `dist/` (clean JS + `.d.ts`) at pack time.
- Dropped the legacy `@possibl/rcrt-api` dependency. The package no longer takes a
  hard wire-client dependency: it consumes the `@possibl/rcrt-sdk` `Breadcrumb`
  type and accepts a host-provided client through structural seams
  (`RcrtClientLike`, the manifest client, `useDataSource`'s client), so the host
  owns the single client instance.
- `@possibl/rcrt-sdk` is a **peer dependency** (`>=0.1.3`) alongside `react` /
  `react-dom`. `lucide-react` is the only runtime dependency.
- Added `tsconfig.json` / `tsconfig.build.json`, `build` + `prepack` scripts,
  `LICENSE`, this changelog and a tag-driven publish workflow (`ui-v*`),
  mirroring `@possibl/rcrt-sdk` and `@possibl/rcrt-app-kit`.

### Type safety (clean strict build)

The package now type-checks and builds cleanly under the same strict config as
the SDK and app-kit (`strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`,
`noUnusedLocals`). Fixed the pre-existing error classes that previously only
surfaced in consumers' vendored copies:

- **`unknown` not assignable to `ReactNode`** — typed config shapes for the
  stream/feed cards (`FactCard`, `HITLCard`, `ReasoningChain`, `ChallengeCard`,
  `DocumentCard`) and boolean-coerced (`!!`) JSX guards across the SAPL
  primitives instead of leaking `unknown` into child position.
- **Implicit `any`** — `@possibl/rcrt-sdk` `Breadcrumb` typing in
  `breadcrumb-to-stream`, explicit types in `useDataSource`.
- **`noUncheckedIndexedAccess` / possibly-undefined** — guarded array and lookup
  access in the SAPL primitives, markdown renderers, manifest publisher,
  `ActivityFeed`, and the studio cards (literal fallbacks for style maps).
- **New-JSX-transform hygiene** — removed unused default `React` imports across
  ~45 widget/chat files; added `breadcrumb` to `WidgetProps`; removed a dangling
  `ChatStreamRenderProps` re-export.
