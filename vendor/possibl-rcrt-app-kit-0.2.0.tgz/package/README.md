# @possibl/rcrt-app-kit

React application framework for [RCRT](https://github.com/possibl-ai/rcrt-v2)
apps. Extracted from the production MSP console: you author **an app
definition** (the Section Registry) plus your domain components, and the
kit derives everything else — router, nav, the `interpret:ui-manifest`
App Control contract, advisor dock + spotlight, page-context grounding,
form prefill plumbing and cached-data chrome.

```
@possibl/rcrt-app-kit/core    platform-agnostic runtime (RN-safe): SWR cache,
                              tenant fan-out, breadcrumb schema helpers
@possibl/rcrt-app-kit/shell   web shell: defineSection/defineApp registry,
                              <RcrtApp>, advisor dock/bus/overlay, manifest
@possibl/rcrt-app-kit/ui      web primitives + `--rcrt-*` design tokens
@possibl/rcrt-app-kit/styles.css
```

## Install

```bash
npm install @possibl/rcrt-app-kit @possibl/rcrt-sdk
# peers: react react-dom react-router-dom zustand
```

## The one rule

**Anything declared twice will eventually disagree.** Every
cross-cutting fact about a section — route, nav entry, anchors, forms,
page context, data chrome — is declared once in `defineSection()`, and
the manifest, router, nav, spotlight anchors and advisor grounding are
projections of it. The four classic wiring bugs (declared anchors with
no DOM, ambiguous form routing, forgotten page context, hand-rolled
cache ceremony) become structurally impossible:

- **Anchors are components, not strings.** `defineAnchor` returns a
  handle whose only render path is `<anchors.foo.Anchor>`; the
  namespaced id (`finance.ar`) is assigned by the registry and the
  manifest lists exactly the anchors that can render. A declared-but-
  unreferenced anchor is an unused variable (`noUnusedLocals`).
- **Forms have namespaced ids + structured semantics.** `intent`,
  `entity` and `distinguishFrom` are first-class manifest fields, not
  free prose; prefills are validated against declared field specs.
- **Page context is computed by the shell** on every location change
  (`{sectionId}:{tab}` by default, `context()` to override). Pages
  cannot set it, so they cannot forget it.
- **Cache ceremony is rendered by the shell.** `SectionPage cache={…}`
  gives every page the refresh button, `UpdatedAgo` honesty chip,
  error banner and `FanoutWarning` for free.

## Quickstart

A complete 2-section app is in
[`examples/basic/app.tsx`](./examples/basic/app.tsx) — 92 lines. The
skeleton:

```tsx
import { RcrtClient } from '@possibl/rcrt-sdk';
import { SwrCache, SwrProvider } from '@possibl/rcrt-app-kit/core';
import { defineApp, defineSection, RcrtApp, localStorageAdapter } from '@possibl/rcrt-app-kit/shell';
import '@possibl/rcrt-app-kit/styles.css';

const overview = defineSection({
  id: 'overview', path: '/overview', label: 'Overview',
  component: OverviewSection,          // your domain UI — real code, slotted in
});

const app = defineApp({
  name: 'my-app', version: '1.0.0',
  branding: { productName: 'My Console' },
  advisor: { suggestions: ['What needs my attention?'] },
  sections: [overview],
});

<BrowserRouter>
  <SwrProvider cache={new SwrCache({ storage: localStorageAdapter() })} scope={userScope}>
    <RcrtApp app={app} client={client} tenantId={tenantId} />
  </SwrProvider>
</BrowserRouter>
```

## Record routes, chromeless takeovers, nav badges (0.2)

A section is no longer first-path-segment only. It can declare **record
routes** — deep-linkable detail views — and opt out of the shell chrome
for full-bleed takeovers. A complete demo is in
[`examples/record-route/app.tsx`](./examples/record-route/app.tsx).

```tsx
const fleet = defineSection({
  id: 'fleet', path: '/fleet', label: 'Fleet', navGroup: 'Operate',
  component: Fleet,
  // Live nav badge (a component — it can use hooks; return null for none).
  navBadge: FleetBadge,
  records: {
    customer: {
      path: 'customers/:id',          // → /fleet/customers/:id
      component: CustomerRecord,       // props: { params, section, record, close }
      chrome: false,                   // full-bleed: no shell header, no nav rail
      // keepParentActive defaults true → Fleet stays highlighted while open.
      // Async page context: the URL has the id; resolve the NAME for grounding.
      context: async ({ params }) => `customer:${await nameOf(params.id)}`,
    },
  },
});
```

- **Record routes** project into the `ui-manifest` (route + anchors +
  forms) like any section, so the advisor can target them. `close()`
  navigates back to the parent section.
- **`chrome`** is `boolean | { header?, nav? }` on a section or record
  route — `false` is a full-bleed takeover; the advisor dock stays.
- **`context`** may be sync or `Promise`-returning, and receives record
  `params` — the shell awaits it and grounds the advisor when it resolves
  (no imperative `setPageContext` wiring).
- **`navSlot: 'top' | 'bottom'`** pins a nav entry into its own ungrouped
  block, so a home item and a settings item can both be ungrouped *and*
  separated. Omit it for the 0.1 grouping behavior.
- **`advisor.groundingTags(base)`** contributes extra grounding tags
  (e.g. a legacy `console-page:` mirror) to every message — no `sendChat`
  wrapper needed. Declare the prefixes in `contextTags` so the manifest
  advertises them.

All six are additive and opt-in: a 0.1 app's config compiles and behaves
unchanged.

## Auth is a seam

The kit never touches Firebase / Auth0 / Clerk. You configure an
`RcrtClient` with whatever `TokenProvider` your app uses and hand it to
`<RcrtApp>`. Templates wire the IdP; the kit stays clean.

## The advisor is inherited, not built

Every app gets the dock (collapsible right panel, ⌘J), guide-card
navigation, the spotlight overlay, `app-page:`/`app-context:` grounding
tags on every message, per-workspace session persistence, and paired-
bundle self-provisioning (`advisor.bundle`). The default chat surface
is the kit's minimal text chat; plug a full JIT-UI surface through
`advisor.renderChat`.

## Theming

All surfaces are driven by `--rcrt-*` CSS variables with a neutral
premium-dark default. Brand by overriding tokens — never by forking
components:

```css
:root {
  --rcrt-accent: #7c3aed;
  --rcrt-accent-2: #ec4899;
  --rcrt-gradient: linear-gradient(135deg, #7c3aed, #ec4899);
}
```

## React Native

`core` is platform-agnostic by construction (storage behind a
`StorageAdapter`, no DOM access) — import `@possibl/rcrt-app-kit/core`
only. A native shell that interprets the same registry is planned; see
the design doc's native path.

## Licence

MIT.
